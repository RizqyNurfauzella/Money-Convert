Nama    : Rizqy Nurfauzella

NIM     : 6706223074

Money Convert adalah aplikasi yang memungkinkan Anda untuk mengonversi mata uang, dan menghitung jumlah total mata uang setelah pajak dikenakan.
Money Convert memberikan kemudahan dalam menghitung nilai tukar mata uang.
Aplikasi ini dibuat untuk membantu pengguna dalam melakukan konversi mata uang secara cepat dan mudah.
